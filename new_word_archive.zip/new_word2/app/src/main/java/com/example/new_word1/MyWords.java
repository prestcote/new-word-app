package com.example.new_word1;

public class MyWords {
    public String word;
    public String part_of_speech;
    public String origin;
    public String meaning;
    public String use_of_word;

    MyWords() {
        word = "Noname";
    }
    MyWords(String word, String part_of_speech, String origin, String meaning, String use_of_word) {
        this.word = word;
        this.part_of_speech = part_of_speech;
        this.origin = origin;
        this.meaning = meaning;
        this.use_of_word = use_of_word;

    }
}

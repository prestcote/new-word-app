package com.example.new_word1;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.fragment.app.FragmentManager;

import android.content.Intent;
import android.database.Cursor;

import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class ListActivity extends AppCompatActivity implements View.OnClickListener  {

    ImageButton mbtnMain, mbtnList, mbtnSettings, mbtnQuiz,  mbtnFavorites;
    final String TAG = "States";
    ListView words_list;
    String[] words;
    EditText search;
    ArrayAdapter<String> adapter;
    List<String> wordsArray;
    int mInd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list);
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);

        mbtnMain = (ImageButton) findViewById(R.id.main);
        mbtnMain.setOnClickListener(this);

        mbtnList = (ImageButton) findViewById(R.id.list);
        mbtnList.setOnClickListener(this);

        mbtnSettings = (ImageButton) findViewById(R.id.settings);
        mbtnSettings.setOnClickListener(this);

        mbtnQuiz = (ImageButton) findViewById(R.id.quiz);
        mbtnQuiz.setOnClickListener(this);

        mbtnFavorites = (ImageButton) findViewById(R.id.favorites);
        mbtnFavorites.setOnClickListener(this);

        words_list = findViewById(R.id.words_list);
        words = getResources().getStringArray(R.array.words_list);
        wordsArray= new ArrayList<>(Arrays.asList(words));

        search = (EditText) findViewById(R.id.search);

        adapter = new ArrayAdapter(this,
                android.R.layout.simple_list_item_1, wordsArray);
        words_list.setAdapter(adapter);

        search.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                ListActivity.this.adapter.getFilter().filter(charSequence);
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {


            }

            @Override
            public void afterTextChanged(Editable editable) {
                adapter.getFilter().filter(editable.toString());

            }
        });
        words_list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View itemClicked, int position,
                                    long id) {
                Intent intent = new Intent(ListActivity.this, ListItemActivity.class);
                String element = ((TextView) itemClicked).getText().toString();
                int elementPos = wordsArray.indexOf(element);
                intent.putExtra("pos", elementPos);
                startActivity(intent);
            }
        });

    }

    @Override
    protected void onStop() {
        super.onStop();
        Log.d(TAG, "MainActivity: onStop() ");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.d(TAG, "MainActivity: onPause() ");
    }

    @Override
    public void onClick(View view) {

        switch (view.getId()) {
            //------МЕНЮ------
            case R.id.list:
                break;
            case R.id.settings:
                showDialogInfo (view);
                break;
            case R.id.main:
                mInd = getIntent().getExtras().getInt("mInd");
                Intent mainAct = new Intent();
                mainAct.setClass(this, MainActivity.class);
                startActivity(mainAct);
                finish();
                break;
            case R.id.quiz:
                Intent quizAct = new Intent();
                quizAct.setClass(this, QuizActivity.class);
                startActivity(quizAct);
                finish();
                break;
            case R.id.favorites:
                Intent favAct = new Intent();
                favAct.setClass(this, FavoriteActivity.class);
                startActivity(favAct);
                break;
        }
    }

    public void showDialogInfo (View view) {
        FragmentManager manager = getSupportFragmentManager();
        DialogFragment_info DialogFragment_info = new DialogFragment_info();
        DialogFragment_info.show(manager, "myDialog_info");
    }
}
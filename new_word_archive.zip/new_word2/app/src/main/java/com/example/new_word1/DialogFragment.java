package com.example.new_word1;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.TextView;

public class DialogFragment extends androidx.fragment.app.DialogFragment {

    int rightAnswers;
    int answers;

    public Dialog onCreateDialog(Bundle savedInstanceState) {
        rightAnswers = getArguments().getInt("rightAnswers");
        answers = getArguments().getInt("answers");
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        LayoutInflater inflater = getActivity().getLayoutInflater();
        View view = inflater.inflate(R.layout.dialog_layout, null);
        builder.setView(view);
        TextView text1 = (TextView) view.findViewById(R.id.textview1);
        text1.setText("Правильные ответы: " + rightAnswers + " из " + answers);
        builder.setTitle("Викторина пройдена!!")
                .setPositiveButton("ОК", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                    }
                });
        return builder.create();
    }

    public static DialogFragment newInstance(int rightAnswers, int answers) {
        DialogFragment fragment = new DialogFragment();
        Bundle args = new Bundle();
        args.putInt("rightAnswers", rightAnswers);
        args.putInt("answers", answers);
        fragment.setArguments(args);
        return fragment;
    }
}

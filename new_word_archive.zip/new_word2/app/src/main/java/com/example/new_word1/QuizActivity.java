package com.example.new_word1;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.fragment.app.FragmentManager;

import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Random;

public class QuizActivity extends AppCompatActivity implements View.OnClickListener {

    ImageButton mbtnMain, mbtnList, mbtnSettings, mbtnQuiz, mbtnFavorites;

    TextView mTextQuest, mScore;
    Button mBtnTrue, mBtnFalse;

    ArrayList<MyQuiz> list;
    MyQuiz mQ;

    int mInd = 0;
    int score = 0;
    int answersRight = 0;
    int answers = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz);
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);

        mbtnMain = (ImageButton) findViewById(R.id.main);
        mbtnMain.setOnClickListener(this);

        mbtnList = (ImageButton) findViewById(R.id.list);
        mbtnList.setOnClickListener(this);

        mbtnSettings = (ImageButton) findViewById(R.id.settings);
        mbtnSettings.setOnClickListener(this);

        mbtnQuiz = (ImageButton) findViewById(R.id.quiz);
        mbtnQuiz.setOnClickListener(this);

        mbtnFavorites = (ImageButton) findViewById(R.id.favorites);
        mbtnFavorites.setOnClickListener(this);

        mTextQuest = (TextView) findViewById(R.id.textQuiz);
        mScore = (TextView) findViewById(R.id.score);
        mBtnFalse = (Button) findViewById(R.id.btnAnswer1);
        mBtnTrue = (Button) findViewById(R.id.btnAnswer2);

        mBtnTrue.setOnClickListener(this);
        mBtnFalse.setOnClickListener(this);

        mScore.setText(score + ""); //набранных очков
        list = new ArrayList<MyQuiz>();

        try {
            String line = (String) getStringFromRawFile(this);
            String lines[] = line.split("#");
            for (int j = 1; j < lines.length; j++) {
                lines[j] = lines[j].substring(2);
            }
            int i = 0;
            while (i < lines.length - 4) {
                MyQuiz mQuest = new MyQuiz(lines[i], lines[i + 1],
                        lines[i+2], lines[i+3]);
                list.add(mQuest);
                i = i + 4;
            }
            mQ = list.get(mInd);
            settings(mQ);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    String convertStreamToString(InputStream is) throws IOException {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        int i = is.read();
        while (i != -1) {
            baos.write(i);
            i = is.read();
        }
        return baos.toString("Cp1251");
    }

    String getStringFromRawFile(Activity activity) throws IOException {
        Resources r = activity.getResources();
        InputStream is = r.openRawResource(R.raw.quiz);
        String myText = convertStreamToString(is);
        is.close();
        return myText;
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            //------МЕНЮ-------
            case R.id.list:
                Intent listAct = new Intent();
                listAct.setClass(this, ListActivity.class);
                startActivity(listAct);
                finish();
                break;
            case R.id.settings:
                showDialogInfo (view);
                break;
            case R.id.main:
                Intent mainAct = new Intent();
                mainAct.setClass(this, MainActivity.class);
                startActivity(mainAct);
                finish();
                break;
            case R.id.quiz:
                break;
            case R.id.favorites:
                Intent favAct = new Intent();
                favAct.setClass(this, FavoriteActivity.class);
                startActivity(favAct);
                break;

            //------КНОПКИ В АКТИВНОСТИ-------
            case R.id.btnAnswer1:
                mInd++;
                if (mInd < list.size()) {
                    if (mQ.answer.equals("1")) {
                        score += 10;
                        answersRight += 1;
                        answers += 1;
                        mScore.setText(score + "");
                        Toast.makeText(this, "Отличная работа!!!", Toast.LENGTH_SHORT).show();
                    } else {
                        mScore.setText(score + "");
                        answers += 1;
                        Toast.makeText(this, "Попробуйте еще раз!!", Toast.LENGTH_SHORT).show();
                    }
                    mQ = list.get(mInd);
                    settings(mQ);
                } else {
                    showDialog(view);
                }
                break;
            case R.id.btnAnswer2:
                mInd++;
                if (mInd < list.size()) {
                    if (mQ.answer.equals("2")) {
                        score += 10;
                        mScore.setText(score + "");
                        answersRight +=1;
                        answers += 1;
                        Toast.makeText(this, "Впечатляет... ответ верный!!", Toast.LENGTH_SHORT).show();
                    } else {
                        mScore.setText(score + "");
                        answers += 1;
                        Toast.makeText(this, "В следующий раз обязательно получится~~~", Toast.LENGTH_SHORT).show();
                    }
                    mQ = list.get(mInd);
                    settings(mQ);
                } else {
                    Toast.makeText(this, "Конец", Toast.LENGTH_LONG).show();
                    showDialog(view);
                }
                break;
        }
    }

    //-------УСТАНОВКА ПАРАМЕТРОВ ВОПРОСА-------
    public void settings(MyQuiz mQ) {
        mTextQuest.setText(mQ.question); // установка нового вопроса
        mBtnTrue.setText(mQ.answer2);
        mBtnFalse.setText(mQ.answer1);
    }

    //--------ПОКАЗАТЬ ДИАЛОГ С РЕЗУЛЬТАТАМИ------
    public void showDialog (View view) {
        FragmentManager manager = getSupportFragmentManager();
        DialogFragment myDialogFragment = DialogFragment.newInstance(answersRight, answers);
        myDialogFragment.show(manager, "myDialog");
    }

    //----------ПОКАЗАТЬ ДИАЛОГ С ИНФОРМАЦИЕЙ-------
    public void showDialogInfo (View view) {
        FragmentManager manager = getSupportFragmentManager();
        DialogFragment_info DialogFragment_info = new DialogFragment_info();
        DialogFragment_info.show(manager, "myDialog_info");
    }
}



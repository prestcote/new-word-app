package com.example.new_word1;

public class MyQuiz {
    public String question;
    public String answer;
    public String answer1;
    public String answer2;


    MyQuiz () { question = "Noname"; }
    MyQuiz(String question, String answer1, String answer2, String answer) {
        this.question = question;
        this.answer = answer;
        this.answer1 = answer1;
        this.answer2 = answer2;

    }
}


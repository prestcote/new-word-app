package com.example.new_word1;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;

import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.Toast;

public class SettingsActivity extends AppCompatActivity implements View.OnClickListener {

    ImageButton mbtnMain, mbtnList, mbtnSettings, mbtnQuiz;
    final String TAG = "States";

    Button mWordRepeat;
    Button mNotifyExist;
    Button mNotifyTime;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);

        mbtnMain = (ImageButton)  findViewById(R.id.main);
        mbtnMain.setOnClickListener(this);

        mbtnList = (ImageButton) findViewById(R.id.list);
        mbtnList.setOnClickListener(this);

        mbtnSettings = (ImageButton) findViewById(R.id.settings);
        mbtnSettings.setOnClickListener(this);

        mbtnQuiz = (ImageButton) findViewById(R.id.quiz);
        mbtnQuiz.setOnClickListener(this);

        mWordRepeat = (Button) findViewById(R.id.repeat);
        mWordRepeat.setOnClickListener(this);

        mNotifyExist = (Button) findViewById(R.id.notify_exist);
        mNotifyExist.setOnClickListener(this);

        mNotifyTime = (Button) findViewById(R.id.notify_time);
        mNotifyTime.setOnClickListener(this);
    }

    @Override
    protected void onStop() {
        super.onStop();
        Log.d(TAG, "MainActivity: onStop() ");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.d(TAG, "MainActivity: onDestroy() ");
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.d(TAG, "MainActivity: onResume() ");
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.d(TAG, "MainActivity: onPause() ");
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.list:
                Intent listAct = new Intent();
                listAct.setClass(this, ListActivity.class);
                startActivity(listAct);
                finish();
                break;
            case R.id.settings:
                break;
            case R.id.main:
                //Toast.makeText(this, "Переход в настройки", Toast.LENGTH_SHORT).show();
                Intent mainAct = new Intent();
                mainAct.setClass(this, MainActivity.class);
                startActivity(mainAct);
                finish();
                break;
            case R.id.quiz:
                //Toast.makeText(this, "Переход в игру", Toast.LENGTH_SHORT).show();
                Intent quizAct = new Intent();
                quizAct.setClass(this, QuizActivity.class);
                startActivity(quizAct);
                finish();
                break;

            case R.id.repeat:
                Toast.makeText(this, "Настроить повтор слова", Toast.LENGTH_SHORT).show();
                break;
            case R.id.notify_exist:
                Toast.makeText(this, "Создать уведомление", Toast.LENGTH_SHORT).show();
                break;
            case R.id.notify_time:
                Toast.makeText(this, "Настроить время появления уведомления", Toast.LENGTH_SHORT).show();
                break;
        }
    }
}
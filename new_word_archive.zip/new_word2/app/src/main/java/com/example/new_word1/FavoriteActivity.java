package com.example.new_word1;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.cursoradapter.widget.SimpleCursorAdapter;
import androidx.fragment.app.FragmentManager;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.Toast;

public class FavoriteActivity extends AppCompatActivity implements View.OnClickListener{

    ImageButton mbtnMain, mbtnList, mbtnSettings, mbtnQuiz, mbtnFavorites;

    ListView favorites_list;
    DatabaseHelper databaseHelper;
    SQLiteDatabase db;
    Cursor userCursor;
    SimpleCursorAdapter userAdapter;
    Button delete;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_favorite);
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);

        mbtnMain = (ImageButton) findViewById(R.id.main);
        mbtnMain.setOnClickListener(this);

        mbtnList = (ImageButton) findViewById(R.id.list);
        mbtnList.setOnClickListener(this);

        mbtnSettings = (ImageButton) findViewById(R.id.settings);
        mbtnSettings.setOnClickListener(this);

        mbtnQuiz = (ImageButton) findViewById(R.id.quiz);
        mbtnQuiz.setOnClickListener(this);

        mbtnFavorites = (ImageButton) findViewById(R.id.favorites);
        mbtnFavorites.setOnClickListener(this);

        delete = (Button) findViewById(R.id.delete);
        delete.setOnClickListener(this);

        favorites_list = (ListView) findViewById(R.id.favorites_list);
        databaseHelper = new DatabaseHelper(getApplicationContext());
    }

    @Override
    public void onResume() {
        super.onResume();
        db = databaseHelper.getReadableDatabase();
        userCursor = db.rawQuery("select * from " + DatabaseHelper.TABLE, null);
        String[] headers = new String[]{DatabaseHelper.COLUMN_NAME};
        userAdapter = new SimpleCursorAdapter(this, android.R.layout.simple_list_item_1,
                userCursor, headers, new int[]{android.R.id.text1}, 0);
        favorites_list.setAdapter(userAdapter);
        favorites_list.setLongClickable(true);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        db.close();
        userCursor.close();
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            //------МЕНЮ------
            case R.id.list:
                Intent listAct = new Intent();
                listAct.setClass(this, ListActivity.class);
                startActivity(listAct);
                finish();
                break;
            case R.id.settings:
                showDialogInfo(view);
                break;
            case R.id.main:
                Intent mainAct = new Intent();
                mainAct.setClass(this, MainActivity.class);
                startActivity(mainAct);
                finish();
                break;
            case R.id.quiz:
                Intent quizAct = new Intent();
                quizAct.setClass(this, QuizActivity.class);
                startActivity(quizAct);
                finish();
                break;
            case R.id.favorites:
                break;

            //-----КНОПКИ В АКТИВНОСТИ
            case R.id.delete:
                db.delete("favorites", null, null);
                userAdapter.notifyDataSetChanged();
                finish();
        }
    }

    public void showDialogInfo (View view) {
        FragmentManager manager = getSupportFragmentManager();
        DialogFragment_info DialogFragment_info = new DialogFragment_info();
        DialogFragment_info.show(manager, "myDialog_info");
    }
}
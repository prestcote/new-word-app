package com.example.new_word1;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.fragment.app.FragmentManager;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Resources;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Random;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    ImageButton mbtnMain, mbtnList, mbtnSettings, mbtnQuiz, mbtnFavorites;
    final String TAG = "States";

    TextView mWord, mPartofspeech, mOrigin, mMeaning, mUseofword;
    ArrayList<MyWords> list;
    MyWords mW;
    ImageButton help, favorites_main_act;
    private static final String PREFS_NAME = "MyPrefsFile";

    int mInd;

    DatabaseHelper sqlHelper;
    SQLiteDatabase db;
    Cursor userCursor;
    long userId=0;

    boolean flag = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);

        mbtnMain = (ImageButton) findViewById(R.id.main);
        mbtnMain.setOnClickListener(this);

        mbtnList = (ImageButton) findViewById(R.id.list);
        mbtnList.setOnClickListener(this);

        mbtnSettings = (ImageButton) findViewById(R.id.settings);
        mbtnSettings.setOnClickListener(this);

        mbtnQuiz = (ImageButton) findViewById(R.id.quiz);
        mbtnQuiz.setOnClickListener(this);

        mbtnFavorites = (ImageButton) findViewById(R.id.favorites);
        mbtnFavorites.setOnClickListener(this);

        mWord = (TextView) findViewById(R.id.word);
        mPartofspeech = (TextView) findViewById(R.id.part_of_speech);
        mOrigin = (TextView) findViewById(R.id.origin);
        mMeaning = (TextView) findViewById(R.id.meaning);
        mUseofword = (TextView) findViewById(R.id.use_of_the_word);

        help = (ImageButton)findViewById(R.id.help) ;
        help.setOnClickListener(this);
        favorites_main_act = (ImageButton) findViewById(R.id.favorites_main_act);
        favorites_main_act.setOnClickListener(this);

        list = new ArrayList<MyWords>();

        try {
            String line = (String) getStringFromRawFile(this);
            String lines[] = line.split("#");
            for (int j = 1; j < lines.length; j++) {
                lines[j] = lines[j].substring(2);
            }

            int i = 0;
            while (i < lines.length - 5) {
                MyWords mWord = new MyWords(lines[i], lines[i + 1], lines[i + 2],
                        lines[i + 3], lines[i + 4]);
                list.add(mWord);
                i = i + 5;
            }
            SharedPreferences index = getSharedPreferences(PREFS_NAME, 0);
            int one = index.getInt("index", mInd);
            mInd = one;
            mW = list.get(mInd);
            settings(mW);

        } catch (IOException e) {
            e.printStackTrace();
        }

        //------РАБОТА С ДАТАБАЗОЙ-----
        sqlHelper = new DatabaseHelper(this);
        db = sqlHelper.getWritableDatabase();

        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            userId = extras.getLong("id");
        }

        if (userId > 0) {
            userCursor = db.rawQuery("select * from " + DatabaseHelper.TABLE + " where " +
                    DatabaseHelper.COLUMN_ID + "=?", new String[]{String.valueOf(userId)});
            userCursor.moveToFirst();
            mWord.setText(userCursor.getString(1));
            userCursor.close();
        }
    }

    //--------ОПРЕДЕЛЕНИЕ СЛЕДУЮЩЕГО СЛОВА СЛУЧАЙНЫМ ОБРАЗОМ-------
    int randomID() {
        int min = 0;
        int max = 101;
        int diff = max - min;
        Random random = new Random();
        mInd = random.nextInt(diff + 1);
        return mInd;
    }


    //----------СТРИМ В СТРОКУ--------
    String convertStreamToString(InputStream is) throws IOException {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        int i = is.read();
        while (i != -1) {
            baos.write(i);
            i = is.read();
        }
        return baos.toString("Cp1251");
    }

    //----------СЧИТЫВАНИЕ ИЗ ТЕКСТОВОГО ФАЙЛА-------
    String getStringFromRawFile(Activity activity) throws IOException {
        Resources r = activity.getResources();
        InputStream is = r.openRawResource(R.raw.mywords);
        String myText = convertStreamToString(is);
        is.close();
        return myText;
    }

    //----------СОХРАНЕНИЕ ПРОГРЕССА ПРИ ОСТАНОВКЕ, ПАУЗЕ ИЛИ УНИЧТОЖЕНИИ АКТИВНОСТИ-----
    @Override
    protected void onStop() {
        super.onStop();
        Log.d(TAG, "MainActivity: onStop() ");
        SharedPreferences index = getSharedPreferences(PREFS_NAME, 0);
        SharedPreferences.Editor editor = index.edit();
        editor.putInt("index", mInd);
        editor.commit();

    }
    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.d(TAG, "MainActivity: onDestroy() ");
        SharedPreferences index = getSharedPreferences(PREFS_NAME, 0);
        SharedPreferences.Editor editor = index.edit();
        editor.putInt("index", mInd);
        editor.commit();
    }
    @Override
    protected void onPause() {
        super.onPause();
        Log.d(TAG, "MainActivity: onPause() ");
        SharedPreferences index = getSharedPreferences(PREFS_NAME, 0);
        SharedPreferences.Editor editor = index.edit();
        editor.putInt("index", mInd);
        editor.commit();
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            //------МЕНЮ-------
            case R.id.list:
                Intent listAct = new Intent();
                listAct.setClass(this, ListActivity.class);
                listAct.putExtra("mInd", mInd);
                startActivity(listAct);
                finish();
                break;
            case R.id.settings:
                showDialogInfo (view);
                break;
            case R.id.main:
                break;
            case R.id.quiz:
                Intent quizAct = new Intent();
                quizAct.setClass(this, QuizActivity.class);
                startActivity(quizAct);
                finish();
                break;
            case R.id.favorites:
                Intent favAct = new Intent();
                favAct.setClass(this, FavoriteActivity.class);
                startActivity(favAct);
                break;

            //------КНОПКИ В АКТИВНОСТИ-------
            case R.id.help:
                flag = false;
                colorChange();
                mInd = randomID();
                if (mInd < list.size()) {
                    mW = list.get(mInd);
                    settings(mW);
                }
                break;
            case R.id.favorites_main_act:
                ContentValues cv = new ContentValues();
                cv.put(DatabaseHelper.COLUMN_NAME, mWord.getText().toString());
                colorChange();

                if (userId > 0) {
                    db.update(DatabaseHelper.TABLE, cv, DatabaseHelper.COLUMN_ID + "=" + userId, null);
                } else {
                    db.insert(DatabaseHelper.TABLE, null, cv);
                }
                break;
        }
    }

    //------СМЕНА ЦВЕТА КНПКИ ДОБАВЛЕНИЯ В ИЗБРАННОЕ-------
    public void colorChange(){
        if (flag)
            favorites_main_act.setImageResource(R.drawable.favorites_on);
        else
            favorites_main_act.setImageResource(R.drawable.favorites_off);
        flag = !flag;
    }

    //------УСТАНОВКА ПАРАМЕТРОВ СЛОВА----------
    public void settings(MyWords mW) {
        mWord.setText(mW.word);
        mPartofspeech.setText(mW.part_of_speech);
        mOrigin.setText(mW.origin);
        mMeaning.setText(mW.meaning);
        mUseofword.setText(mW.use_of_word);
    }

    //--------ОТКРЫТЬ ДИАЛОГ С ИНФОРМАЦИЕЙ-------
    public void showDialogInfo (View view) {
        FragmentManager manager = getSupportFragmentManager();
        DialogFragment_info DialogFragment_info = new DialogFragment_info();
        DialogFragment_info.show(manager, "myDialog_info");
    }
}


